import json
from app.multi_llm.schemas.tool_call import ToolCall
from app.multi_llm.tools.registry import TOOL_SPECS, tools_prompt_block
from app.multi_llm.llm.provider import MistralProvider

async def decide_llm(self, world: "WorldState", provider: "MistralProvider") -> "Action":
    """
    LLM-driven decision: model returns a ToolCall (tool + arguments),
    then we validate using tool schemas and convert to Action.
    """

    # Minimal world context to reduce tokens
    world_payload = {
        "turn": world.turn,
        "self": self.country_id,
        "countries": [{"id": c.id, "name": c.name, "economy": c.economy, "military_power": c.military_power} for c in world.countries],
        "relations": [{"country_1": r.country_1, "country_2": r.country_2, "relation": r.relation} for r in world.relations],
    }

    messages = [
        {
            "role": "system",
            "content": (
                f"You are {self.country_name} ({self.country_id}).\n"
                "Choose exactly ONE tool that best serves your interests this turn.\n"
                "Be aggressive if relations are bad and you have high military_power.\n\n"
                + tools_prompt_block() + "\n\n"
                "Output JSON with this schema:\n"
                '{ "tool": "DECLARE_WAR|ALLY|TRADE", "arguments": { ... } }\n'
            ),
        },
        {
            "role": "user",
            "content": "WORLD:\n" + json.dumps(world_payload, indent=2),
        },
    ]

    tool_call = await provider.complete_json(messages=messages, schema=ToolCall)

    # Validate tool name
    if tool_call.tool not in TOOL_SPECS:
        return Action(actor_id=self.country_id, type=ActionType.PASS, reason="Unknown tool from model", intensity=1)

    # Validate tool arguments with Pydantic
    args_model = TOOL_SPECS[tool_call.tool]["args_model"]
    validate_fn = TOOL_SPECS[tool_call.tool]["validate"]

    args = args_model.model_validate(tool_call.arguments)
    validate_fn(args, world, self.country_id)

    # Convert tool call -> canonical Action
    return Action(
        actor_id=self.country_id,
        type=ActionType(tool_call.tool),          # must match enum values
        target_id=getattr(args, "target_id", None),
        reason=getattr(args, "reason", "No reason"),
        intensity=getattr(args, "intensity", 1),
    )